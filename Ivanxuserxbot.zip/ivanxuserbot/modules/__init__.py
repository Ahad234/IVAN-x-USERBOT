# Import all modules to register handlers
from .system import *
from .admin import *
from .message import *
from .info import *
from .afk import *
from .fun import *
from .funanimation import *
from .media import *
from .dev import *
from .extra import *
from .couple import *
from .tools import *
from .stats import *
