import time
START_TIME = time.time()
def get_uptime():
    seconds = int(time.time() - START_TIME)
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    uptime = (f"{days}d " if days else "") + (f"{hours}h " if hours else "") + \
             (f"{minutes}m " if minutes else "") + f"{seconds}s"
    return uptime
