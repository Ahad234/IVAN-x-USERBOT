import logging, asyncio
from telethon import TelegramClient
from .config import API_ID, API_HASH, SESSION
logging.basicConfig(level=logging.INFO)
client = TelegramClient(SESSION, API_ID, API_HASH)
def load_modules():
    # import modules so handlers register
    import ivanxuserbot.modules  # noqa: F401
    # schedule startup banner if available
    try:
        from ivanxuserbot.startup.startup import send_startup_banner
        client.loop.create_task(send_startup_banner())
    except Exception:
        pass
def start_bot():
    load_modules()
    print("🚀 Starting ivanxuserbot...")
    client.start()
    print("✅ ivanxuserbot running.")
    client.run_until_disconnected()
if __name__ == "__main__":
    start_bot()
