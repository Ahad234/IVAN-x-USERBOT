import os
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
SESSION = os.getenv("SESSION", "ivanxuserbot")
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
