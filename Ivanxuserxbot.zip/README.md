    ivanxuserbot - template userbot


    Files:

    - ivanxuserbot/: package
    - modules/: command modules
    - core.py: client loader/startup

Set env vars API_ID, API_HASH, OWNER_ID and run:

    pip install -r requirements.txt
    python -m ivanxuserbot.core
